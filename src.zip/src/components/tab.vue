<template>
    <div>
        <div class="box">
        <div class="tab">
            <ul class="clear">
                <li v-for="(item,index ) in items" :class="{'active': index == n}" @click="choose(index)" :key="index">
                    {{item.title}}
                </li>
            </ul>
            <div class="content">
                <p>{{items[n].content}}</p>
            </div>
        </div>

    </div>
    </div>
</template>
<script>
export default {
    data(){
        return {
            items: [
                    {title: 'tab一', content: '我的内容是北京'},
                    {title: 'tab二', content: '我的内容是上海'},
                    {title: 'tab三', content: '我的内容是广州'},
                    {title: 'tab四', content: '我的内容是深圳'},
                    {title: 'tab五', content: '我的内容是武汉'}
                ],
            n: 0
        }
    },
    methods:{
        choose(index) {
            this.n = index;
        }
    }
}
</script>

<style scoped>
.box {
            margin: 100px auto 0;
            width: 80%;
        }
        .clear:after {
            content: '';
            display: block;
            clear: both;
        }
        .tab {
            width: 600px;
            border: 1px solid #dcdfe6;
            box-shadow: 0 2px 4px 0 rgba(0,0,0,.2);
        }
        ul {
            margin: 0;
            padding: 0;
            list-style: none;
            background: #f5f7fa;
            border-bottom: 1px solid #e4e7ed;
            position: relative;
        }
        li {
            float: left;
            padding: 0 20px;
            margin: 0 0 -1px -1px;
            position: relative;
            height: 40px;
            border: 1px solid transparent;
            line-height: 40px;
            cursor: pointer;
            transition: .2s all;
        }
        li:hover {
            color: rgb(64, 158, 255);
        }
        li.active {
            background: #fff;
            border-right-color: #dcdfe6;
            border-left-color: #dcdfe6;
            color: rgb(64, 158, 255);
        }
        
        .tab .content {
            padding: 10px;
        }
</style>