<template>
  <div class="hello" style="background:#ccc">
    <div class="clear" >
      <coll>
          <div>折叠折叠666</div>
      </coll>
      <div>折叠组件</div>
    </div>
    
    <div  style="background:#fff;"><div class="box"></div> </div>
    样式组件
    
    <div class="less">
      <div class="lessbox">333</div>
    </div>

    <tab></tab>
  </div>
</template>

<script>
import coll from "./collapse"
import tab from "./tab"
export default {
  components:{coll,tab},
  name: 'HelloWorld',
  data () {
    return {
      toggle:false,
      msg: 'Welcome to Your Vue.js App'
    }
  },
  methods:{
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
  .clear::after{
    content:'';
    height:0;
    visibility: hidden;
    clear: both;
  }
  .box{
    width: 100px;height:40px;
    /* margin-top: 30px; */
    background: linear-gradient(-68deg, transparent 17px, #58a 0);
  }
</style>
<style lang="less">

.less{
  .lessbox{
    border:1px solid #000;
    &:hover{
      background:rgb(135, 228, 245);
    }
  }
}
</style>