<template>
    <div>
test
    </div>    
</template>
<script>
    import header from "./heade"
    import footer from "./forter"
    export default {
        
    }
</script>
<style>

</style>