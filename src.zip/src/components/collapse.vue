<template>
  <div>
      
      <div class="content" @click="togglenv">
        <div :class="['select',toggle?'open':'']">
            <p>所有选项</p>
            <div class="context">
                <slot></slot>
            </div>
        </div>
      </div>
  
  </div>
</template>
<script>
export default {
  name: 'HelloWorld',
  data () {
    return {
      toggle:false,
      
    }
  },
  methods:{
    togglenv(){
      this.toggle = !this.toggle;
    }
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
.content {
    padding-top: 5%;
}           
.content .select {
    width: 400px;
    /* height: 40px; */
    margin: 0 auto;
    font-family: "Microsoft Yahei";
    font-size: 16px;
    background-color: #fff;
    position: relative;
}
/*transform(缩放、旋转、平移)，显示的是最终效果，没有动画过程*/
/*transition是对元素本身的属性(比如：width、height)设置动画效果*/          
.content .select:after {
    content: '';
    display: block;
    width: 10px;
    height: 10px;
    border-left: 1px #ccc solid;
    border-bottom: 1px #ccc solid;
    position: absolute;
    top: 11px;
    right: 12px;
    transform: rotate(-45deg);
    transition: transform .3 ease-out,top .3s ease-out;
}           
.content .select p {
    text-align: left;
    padding: 0 15px;
    margin:0;
    line-height: 40px;
    cursor: pointer;
    border-bottom:1px solid #f0f0f0;
}
/*设置下拉框收起时的高度过渡动画*/         
.content .select .context {
    list-style-type: none;
    background-color: #fff;
    width: 100%;
    overflow: hidden;
    /* position: absolute;
    top: 41px;
    left: 0; */
    max-height: 0;
    transition: max-height .3s ease-out;
}           
.content .select ul li {
    padding: 0 15px;
    line-height: 40px;
    cursor: pointer;
}           
/* .content .select ul li:hover {
    background-color: #e0e0e0;
}           
.content .select ul li.selected {
    background-color: #39f;
    color: #fff;
} */
/*下拉框展开时调用动画slide-down*/
/*transform-origin设置缩放下拉框的基点位置*/            
.content .select.open .context {
    max-height: 700px;
    -webkit-animation: slide-down .5s ease-in;
    transition: max-height .3s ease-in;
    transform-origin: 50% 0; 
}
/*设置展开时下拉箭头的旋转动画*/          
.content .select.open:after {
    transform: rotate(-225deg);
    top: 18px;
    transition: all .3s ease-in-out;
}
/*为下拉框展开时添加名称为slide-down的关键帧动画*/
@-webkit-keyframes slide-down{
    0%{transform: scale(1,0);}
    25%{transform: scale(1,1.2);}
    50%{transform: scale(1,0.85);}
    75%{transform: scale(1,1.05);}
    100%{transform: scale(1,1);}
}
</style>
