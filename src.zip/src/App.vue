<template>
  <div id="app" > 
    <div v-for="(item,index) in list" :key="index" style="margin-right:20px;display:inline-block;">
      <router-link :to="item.path" exact ><span >{{item.title}}</span></router-link>
    </div>
       <!-- <router-link to="/topics/11"><span>异步请求测试</span></router-link>
       <router-link to="/counter"><span>状态管理测试</span></router-link>
       <router-link to="/about"><span>无状态组件测试</span></router-link> -->
       <!-- <router-link to="/" exact ><span >22</span></router-link>
       <router-link to="/test"><span>测试</span></router-link> -->

    <router-view/>
  </div>
</template>

<script>
export default {
  name: 'App',
  data(){
    return {
        list:[{path:'/',title:'首页'},{path:'/test',title:'测试'}],
        ind:0
    }
  },
  methods:{
    changeBgc(index){
      this.ind = index;
    }
  }
}
</script>

<style>
#app {
  font-family: 'Avenir', Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
  margin-top: 60px;
}
a{
  text-decoration: none;
  color:#2c3e50;
}
.router-link-exact-active{
  border-bottom:2px solid #dddddd;
  text-align:center;
}
.topbar-item{
}
</style>
