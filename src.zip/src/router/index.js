import Vue from 'vue'
import Router from 'vue-router'
import HelloWorld from '@/components/HelloWorld'
import tab from '@/components/tab'

Vue.use(Router)

export default new Router({
  mode:"history",
  linkActiveClass:'router-link-exact-active',
  routes: [
    { path: '/', component: HelloWorld },
    // { path: '/topics/:id', component: Topics },
    // { path: '/counter', component: Counter },
    // { path: '/about', component: () => import('../components/About.vue')},
    { path: '/test', component:tab}
  ]
})
